var searchData=
[
  ['nbtransactions',['nbTransactions',['../class_mode_auto.html#a197e1a108aceda2a65d42112332eed37',1,'ModeAuto']]]
];
